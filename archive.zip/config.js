window.HGAC_HOMEPAGE_DEMOS=true;
window.HGAC_SERVER="";